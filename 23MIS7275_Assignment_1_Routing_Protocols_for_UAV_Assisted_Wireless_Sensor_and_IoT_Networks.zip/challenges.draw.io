<mxfile host="app.diagrams.net" modified="2026-04-25T12:00:00.000Z" agent="ChatGPT" version="24.7.17">
  <diagram id="uav-iot-challenges" name="Page-1">
    <mxGraphModel dx="1600" dy="900" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1200" pageHeight="800" math="0" shadow="0">
      <root>
        <mxCell id="0"/>
        <mxCell id="1" parent="0"/>

        <!-- Center ellipse -->
        <mxCell id="center" value="Trajectory&#xa;Challenges in&#xa;UAV assisted&#xa;IoT&#xa;Applications" style="ellipse;whiteSpace=wrap;html=1;strokeColor=#a33a3a;strokeWidth=3;fillColor=#dfe8f7;fontSize=18;fontStyle=1;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="420" y="150" width="240" height="360" as="geometry"/>
        </mxCell>

        <!-- Left boxes -->
        <mxCell id="l1" value="Network Performance" style="shape=mxgraph.basic.rect;rounded=0;whiteSpace=wrap;html=1;strokeColor=#7f8c69;strokeWidth=2;fillColor=#d8e0c2;fontSize=16;fontStyle=1;shadow=1;" vertex="1" parent="1">
          <mxGeometry x="20" y="40" width="250" height="70" as="geometry"/>
        </mxCell>
        <mxCell id="l2" value="Landing" style="shape=mxgraph.basic.rect;rounded=0;whiteSpace=wrap;html=1;strokeColor=#7f8c69;strokeWidth=2;fillColor=#d8e0c2;fontSize=16;fontStyle=1;shadow=1;" vertex="1" parent="1">
          <mxGeometry x="20" y="130" width="250" height="70" as="geometry"/>
        </mxCell>
        <mxCell id="l3" value="Obstacle Collision/FOD" style="shape=mxgraph.basic.rect;rounded=0;whiteSpace=wrap;html=1;strokeColor=#7f8c69;strokeWidth=2;fillColor=#d8e0c2;fontSize=16;fontStyle=1;shadow=1;" vertex="1" parent="1">
          <mxGeometry x="20" y="220" width="250" height="70" as="geometry"/>
        </mxCell>
        <mxCell id="l4" value="Dynamic Distance" style="shape=mxgraph.basic.rect;rounded=0;whiteSpace=wrap;html=1;strokeColor=#7f8c69;strokeWidth=2;fillColor=#d8e0c2;fontSize=16;fontStyle=1;shadow=1;" vertex="1" parent="1">
          <mxGeometry x="20" y="310" width="250" height="70" as="geometry"/>
        </mxCell>
        <mxCell id="l5" value="Platform" style="shape=mxgraph.basic.rect;rounded=0;whiteSpace=wrap;html=1;strokeColor=#7f8c69;strokeWidth=2;fillColor=#d8e0c2;fontSize=16;fontStyle=1;shadow=1;" vertex="1" parent="1">
          <mxGeometry x="20" y="400" width="250" height="70" as="geometry"/>
        </mxCell>
        <mxCell id="l6" value="Network lifetime" style="shape=mxgraph.basic.rect;rounded=0;whiteSpace=wrap;html=1;strokeColor=#7f8c69;strokeWidth=2;fillColor=#d8e0c2;fontSize=16;fontStyle=1;shadow=1;" vertex="1" parent="1">
          <mxGeometry x="20" y="490" width="250" height="70" as="geometry"/>
        </mxCell>

        <!-- Right boxes -->
        <mxCell id="r1" value="Inference management" style="shape=mxgraph.basic.rect;rounded=0;whiteSpace=wrap;html=1;strokeColor=#7f8c69;strokeWidth=2;fillColor=#d8e0c2;fontSize=16;fontStyle=1;shadow=1;" vertex="1" parent="1">
          <mxGeometry x="800" y="40" width="250" height="70" as="geometry"/>
        </mxCell>
        <mxCell id="r2" value="Height management" style="shape=mxgraph.basic.rect;rounded=0;whiteSpace=wrap;html=1;strokeColor=#7f8c69;strokeWidth=2;fillColor=#d8e0c2;fontSize=16;fontStyle=1;shadow=1;" vertex="1" parent="1">
          <mxGeometry x="800" y="130" width="250" height="70" as="geometry"/>
        </mxCell>
        <mxCell id="r3" value="Weather Condition" style="shape=mxgraph.basic.rect;rounded=0;whiteSpace=wrap;html=1;strokeColor=#7f8c69;strokeWidth=2;fillColor=#d8e0c2;fontSize=16;fontStyle=1;shadow=1;" vertex="1" parent="1">
          <mxGeometry x="800" y="220" width="250" height="70" as="geometry"/>
        </mxCell>
        <mxCell id="r4" value="Horizontal Distance" style="shape=mxgraph.basic.rect;rounded=0;whiteSpace=wrap;html=1;strokeColor=#7f8c69;strokeWidth=2;fillColor=#d8e0c2;fontSize=16;fontStyle=1;shadow=1;" vertex="1" parent="1">
          <mxGeometry x="800" y="310" width="250" height="70" as="geometry"/>
        </mxCell>
        <mxCell id="r5" value="Vertical Distance" style="shape=mxgraph.basic.rect;rounded=0;whiteSpace=wrap;html=1;strokeColor=#7f8c69;strokeWidth=2;fillColor=#d8e0c2;fontSize=16;fontStyle=1;shadow=1;" vertex="1" parent="1">
          <mxGeometry x="800" y="400" width="250" height="70" as="geometry"/>
        </mxCell>
        <mxCell id="r6" value="Time management" style="shape=mxgraph.basic.rect;rounded=0;whiteSpace=wrap;html=1;strokeColor=#7f8c69;strokeWidth=2;fillColor=#d8e0c2;fontSize=16;fontStyle=1;shadow=1;" vertex="1" parent="1">
          <mxGeometry x="800" y="490" width="250" height="70" as="geometry"/>
        </mxCell>
        <mxCell id="r7" value="Connectivity management" style="shape=mxgraph.basic.rect;rounded=0;whiteSpace=wrap;html=1;strokeColor=#7f8c69;strokeWidth=2;fillColor=#d8e0c2;fontSize=16;fontStyle=1;shadow=1;" vertex="1" parent="1">
          <mxGeometry x="800" y="580" width="250" height="70" as="geometry"/>
        </mxCell>

        <!-- Left arrows -->
        <mxCell id="e1" style="endArrow=classic;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="l1" target="center">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="330" y="75"/>
            </Array>
          </mxGeometry>
        </mxCell>
        <mxCell id="e2" style="endArrow=classic;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="l2" target="center">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="330" y="165"/>
            </Array>
          </mxGeometry>
        </mxCell>
        <mxCell id="e3" style="endArrow=classic;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="l3" target="center">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="330" y="255"/>
            </Array>
          </mxGeometry>
        </mxCell>
        <mxCell id="e4" style="endArrow=classic;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="l4" target="center">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="330" y="345"/>
            </Array>
          </mxGeometry>
        </mxCell>
        <mxCell id="e5" style="endArrow=classic;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="l5" target="center">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="330" y="435"/>
            </Array>
          </mxGeometry>
        </mxCell>
        <mxCell id="e6" style="endArrow=classic;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="l6" target="center">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="330" y="525"/>
            </Array>
          </mxGeometry>
        </mxCell>

        <!-- Right arrows -->
        <mxCell id="e7" style="startArrow=classic;endArrow=classic;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="center" target="r1">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="730" y="75"/>
            </Array>
          </mxGeometry>
        </mxCell>
        <mxCell id="e8" style="startArrow=classic;endArrow=classic;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="center" target="r2">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="730" y="165"/>
            </Array>
          </mxGeometry>
        </mxCell>
        <mxCell id="e9" style="startArrow=classic;endArrow=classic;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="center" target="r3">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="730" y="255"/>
            </Array>
          </mxGeometry>
        </mxCell>
        <mxCell id="e10" style="startArrow=classic;endArrow=classic;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="center" target="r4">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="730" y="345"/>
            </Array>
          </mxGeometry>
        </mxCell>
        <mxCell id="e11" style="startArrow=classic;endArrow=classic;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="center" target="r5">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="730" y="435"/>
            </Array>
          </mxGeometry>
        </mxCell>
        <mxCell id="e12" style="startArrow=classic;endArrow=classic;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="center" target="r6">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="730" y="525"/>
            </Array>
          </mxGeometry>
        </mxCell>
        <mxCell id="e13" style="startArrow=classic;endArrow=classic;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="center" target="r7">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="730" y="615"/>
            </Array>
          </mxGeometry>
        </mxCell>

        <!-- Left bracket -->
        <mxCell id="leftBracket" value="{" style="text;html=1;strokeColor=none;fillColor=none;fontSize=140;fontStyle=1;rotation=180;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="290" y="110" width="60" height="470" as="geometry"/>
        </mxCell>

        <!-- Right bracket -->
        <mxCell id="rightBracket" value="}" style="text;html=1;strokeColor=none;fillColor=none;fontSize=140;fontStyle=1;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="720" y="100" width="60" height="560" as="geometry"/>
        </mxCell>

      </root>
    </mxGraphModel>
  </diagram>
</mxfile>