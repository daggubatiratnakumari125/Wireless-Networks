<mxfile host="app.diagrams.net" modified="2026-04-25T00:00:00.000Z" agent="ChatGPT" version="24.7.17">
  <diagram id="uav-arch-1" name="Page-1">
    <mxGraphModel dx="1434" dy="794" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1600" pageHeight="1000" math="0" shadow="0">
      <root>
        <mxCell id="0"/>
        <mxCell id="1" parent="0"/>

        <!-- Title -->
        <mxCell id="title" value="Architecture of UAV-Assisted WSN and IoT Network" style="text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;fontSize=26;fontStyle=1;" vertex="1" parent="1">
          <mxGeometry x="350" y="20" width="900" height="40" as="geometry"/>
        </mxCell>

        <!-- Feature boxes -->
        <mxCell id="mobility" value="Mobility-Aware&#xa;Routing" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="70" y="100" width="220" height="80" as="geometry"/>
        </mxCell>

        <mxCell id="energy" value="Energy-Efficient&#xa;Routing" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="1210" y="100" width="220" height="80" as="geometry"/>
        </mxCell>

        <mxCell id="latency" value="Latency-Aware&#xa;Delivery" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="420" y="780" width="220" height="80" as="geometry"/>
        </mxCell>

        <mxCell id="secure" value="Secure&#xa;Communication" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="860" y="780" width="220" height="80" as="geometry"/>
        </mxCell>

        <!-- Ground sensor nodes -->
        <mxCell id="ground" value="Ground Sensor Nodes / IoT Devices" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=18;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="40" y="620" width="520" height="110" as="geometry"/>
        </mxCell>

        <!-- Cluster heads -->
        <mxCell id="ch1" value="Cluster Head /&#xa;Local&#xa;Aggregator" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=14;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="40" y="340" width="160" height="140" as="geometry"/>
        </mxCell>

        <mxCell id="ch2" value="Cluster Head /&#xa;Local&#xa;Aggregator" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=14;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="220" y="340" width="160" height="140" as="geometry"/>
        </mxCell>

        <mxCell id="ch3" value="Cluster Head /&#xa;Local&#xa;Aggregator" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=14;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="400" y="340" width="160" height="140" as="geometry"/>
        </mxCell>

        <mxCell id="dots" value="..." style="text;html=1;strokeColor=none;fillColor=none;fontSize=28;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="565" y="385" width="40" height="40" as="geometry"/>
        </mxCell>

        <!-- Main UAV -->
        <mxCell id="uav" value="UAV Data&#xa;Collection /&#xa;Aerial Relay" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=18;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="650" y="330" width="190" height="180" as="geometry"/>
        </mxCell>

        <!-- Neighbor UAV -->
        <mxCell id="neighbor" value="Neighbor UAV" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=18;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="620" y="120" width="250" height="90" as="geometry"/>
        </mxCell>

        <!-- Right side blocks -->
        <mxCell id="gateway" value="Base Station /&#xa;Gateway" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="910" y="365" width="170" height="110" as="geometry"/>
        </mxCell>

        <mxCell id="cloud" value="Edge /&#xa;Cloud Server" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="1120" y="365" width="170" height="110" as="geometry"/>
        </mxCell>

        <mxCell id="apps" value="Applications /&#xa;Users" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="1330" y="365" width="170" height="110" as="geometry"/>
        </mxCell>

        <!-- Labels -->
        <mxCell id="dataLbl" value="Data Collection" style="text;html=1;strokeColor=none;fillColor=none;fontSize=16;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="195" y="535" width="180" height="30" as="geometry"/>
        </mxCell>

        <mxCell id="aggLbl" value="Aggregation&#xa;Upload" style="text;html=1;strokeColor=none;fillColor=none;fontSize=16;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="520" y="490" width="150" height="50" as="geometry"/>
        </mxCell>

        <mxCell id="multiLbl" value="Multi-hop Relay" style="text;html=1;strokeColor=none;fillColor=none;fontSize=16;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="805" y="245" width="160" height="30" as="geometry"/>
        </mxCell>

        <!-- Caption -->
        <mxCell id="caption" value="Figure: Simplified architecture of UAV-assisted wireless sensor and IoT networks." style="text;html=1;strokeColor=none;fillColor=none;fontSize=16;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="300" y="920" width="1000" height="30" as="geometry"/>
        </mxCell>

        <!-- Dashed arrows from ground to cluster heads -->
        <mxCell id="e1" style="endArrow=block;html=1;rounded=0;strokeColor=#1a5fb4;dashed=1;dashPattern=8 8;strokeWidth=2;" edge="1" parent="1" source="ground" target="ch1">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="120" y="620"/>
              <mxPoint x="120" y="520"/>
            </Array>
          </mxGeometry>
        </mxCell>

        <mxCell id="e2" style="endArrow=block;html=1;rounded=0;strokeColor=#1a5fb4;dashed=1;dashPattern=8 8;strokeWidth=2;" edge="1" parent="1" source="ground" target="ch2">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="300" y="620"/>
              <mxPoint x="300" y="520"/>
            </Array>
          </mxGeometry>
        </mxCell>

        <mxCell id="e3" style="endArrow=block;html=1;rounded=0;strokeColor=#1a5fb4;dashed=1;dashPattern=8 8;strokeWidth=2;" edge="1" parent="1" source="ground" target="ch3">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="480" y="620"/>
              <mxPoint x="480" y="520"/>
            </Array>
          </mxGeometry>
        </mxCell>

        <!-- Cluster heads to UAV -->
        <mxCell id="e4" style="endArrow=block;html=1;rounded=0;strokeColor=#1a5fb4;strokeWidth=2;" edge="1" parent="1" source="ch1" target="uav">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <mxCell id="e5" style="endArrow=block;html=1;rounded=0;strokeColor=#1a5fb4;strokeWidth=2;" edge="1" parent="1" source="ch2" target="uav">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <mxCell id="e6" style="endArrow=block;html=1;rounded=0;strokeColor=#1a5fb4;strokeWidth=2;" edge="1" parent="1" source="ch3" target="uav">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <!-- Neighbor UAV double arrow -->
        <mxCell id="e7" style="startArrow=block;endArrow=block;html=1;rounded=0;strokeColor=#1a5fb4;strokeWidth=2;" edge="1" parent="1" source="uav" target="neighbor">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <!-- Right flow arrows -->
        <mxCell id="e8" style="endArrow=block;html=1;rounded=0;strokeColor=#1a5fb4;strokeWidth=2;" edge="1" parent="1" source="uav" target="gateway">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <mxCell id="e9" style="endArrow=block;html=1;rounded=0;strokeColor=#1a5fb4;strokeWidth=2;" edge="1" parent="1" source="gateway" target="cloud">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <mxCell id="e10" style="endArrow=block;html=1;rounded=0;strokeColor=#1a5fb4;strokeWidth=2;" edge="1" parent="1" source="cloud" target="apps">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

      </root>
    </mxGraphModel>
  </diagram>
</mxfile>