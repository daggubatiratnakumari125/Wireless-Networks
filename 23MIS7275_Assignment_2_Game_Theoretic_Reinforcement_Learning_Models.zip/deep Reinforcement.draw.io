<mxfile host="app.diagrams.net" modified="2026-04-25T12:00:00.000Z" agent="ChatGPT" version="24.7.17">
  <diagram id="drl-ids-arch" name="Page-1">
    <mxGraphModel dx="1546" dy="878" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1400" pageHeight="700" math="0" shadow="0">
      <root>
        <mxCell id="0"/>
        <mxCell id="1" parent="0"/>

        <!-- Left title text -->
        <mxCell id="t1" value="IoT Devices &amp;&#xa;Network Traffic" style="text;html=1;strokeColor=none;fillColor=none;align=left;verticalAlign=middle;fontSize=16;fontStyle=1;" vertex="1" parent="1">
          <mxGeometry x="20" y="30" width="150" height="50" as="geometry"/>
        </mxCell>

        <!-- Left icons simplified -->
        <mxCell id="cloud" value="" style="shape=cloud;whiteSpace=wrap;html=1;fillColor=#1f5aa6;strokeColor=#1f5aa6;" vertex="1" parent="1">
          <mxGeometry x="20" y="90" width="40" height="25" as="geometry"/>
        </mxCell>

        <mxCell id="device1" value="" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#4d4d4d;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="68" y="82" width="22" height="40" as="geometry"/>
        </mxCell>

        <mxCell id="device2" value="" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#4d4d4d;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="28" y="125" width="45" height="28" as="geometry"/>
        </mxCell>

        <mxCell id="graphline" value="" style="shape=line;strokeColor=#1f5aa6;strokeWidth=3;" vertex="1" parent="1">
          <mxGeometry x="36" y="145" width="28" height="1" as="geometry"/>
        </mxCell>

        <!-- Data preprocessing box -->
        <mxCell id="prep" value="Data Preprocessing" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f2f2f2;strokeColor=#9e9e9e;strokeWidth=2;fontSize=16;fontStyle=1;align=center;verticalAlign=top;spacingTop=10;" vertex="1" parent="1">
          <mxGeometry x="110" y="70" width="170" height="110" as="geometry"/>
        </mxCell>

        <mxCell id="norm" value="Normalization" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#1f5aa6;strokeColor=#1f5aa6;fontColor=#ffffff;fontSize=15;fontStyle=1;" vertex="1" parent="1">
          <mxGeometry x="130" y="103" width="130" height="28" as="geometry"/>
        </mxCell>

        <mxCell id="featselect" value="Feature Selection" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#2c6cc4;strokeColor=#2c6cc4;fontColor=#ffffff;fontSize=15;fontStyle=1;" vertex="1" parent="1">
          <mxGeometry x="130" y="139" width="130" height="28" as="geometry"/>
        </mxCell>

        <!-- Feature extraction narrow box -->
        <mxCell id="featurebox" value="Feature&#xa;Extraction" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#bfbfbf;strokeWidth=2;fontSize=15;fontStyle=1;" vertex="1" parent="1">
          <mxGeometry x="325" y="82" width="68" height="78" as="geometry"/>
        </mxCell>

        <mxCell id="bulletText" value="• Statistical&#xa;  Features&#xa;• Temporal&#xa;  Features" style="text;html=1;strokeColor=none;fillColor=none;align=left;verticalAlign=top;fontSize=13;" vertex="1" parent="1">
          <mxGeometry x="332" y="165" width="95" height="70" as="geometry"/>
        </mxCell>

        <!-- DRL model box -->
        <mxCell id="drl" value="DRL Model" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#efe8c9;strokeColor=#999999;strokeWidth=2;fontSize=16;fontStyle=1;align=center;verticalAlign=top;spacingTop=8;" vertex="1" parent="1">
          <mxGeometry x="430" y="55" width="235" height="145" as="geometry"/>
        </mxCell>

        <!-- neural net dots -->
        <mxCell id="n1" value="" style="ellipse;whiteSpace=wrap;html=1;fillColor=#1f5aa6;strokeColor=#1f5aa6;" vertex="1" parent="1"><mxGeometry x="490" y="93" width="10" height="10" as="geometry"/></mxCell>
        <mxCell id="n2" value="" style="ellipse;whiteSpace=wrap;html=1;fillColor=#1f5aa6;strokeColor=#1f5aa6;" vertex="1" parent="1"><mxGeometry x="490" y="113" width="10" height="10" as="geometry"/></mxCell>
        <mxCell id="n3" value="" style="ellipse;whiteSpace=wrap;html=1;fillColor=#1f5aa6;strokeColor=#1f5aa6;" vertex="1" parent="1"><mxGeometry x="490" y="133" width="10" height="10" as="geometry"/></mxCell>

        <mxCell id="n4" value="" style="ellipse;whiteSpace=wrap;html=1;fillColor=#666666;strokeColor=#666666;" vertex="1" parent="1"><mxGeometry x="535" y="82" width="10" height="10" as="geometry"/></mxCell>
        <mxCell id="n5" value="" style="ellipse;whiteSpace=wrap;html=1;fillColor=#666666;strokeColor=#666666;" vertex="1" parent="1"><mxGeometry x="535" y="102" width="10" height="10" as="geometry"/></mxCell>
        <mxCell id="n6" value="" style="ellipse;whiteSpace=wrap;html=1;fillColor=#666666;strokeColor=#666666;" vertex="1" parent="1"><mxGeometry x="535" y="122" width="10" height="10" as="geometry"/></mxCell>
        <mxCell id="n7" value="" style="ellipse;whiteSpace=wrap;html=1;fillColor=#666666;strokeColor=#666666;" vertex="1" parent="1"><mxGeometry x="535" y="142" width="10" height="10" as="geometry"/></mxCell>

        <mxCell id="n8" value="" style="ellipse;whiteSpace=wrap;html=1;fillColor=#888888;strokeColor=#888888;" vertex="1" parent="1"><mxGeometry x="580" y="93" width="10" height="10" as="geometry"/></mxCell>
        <mxCell id="n9" value="" style="ellipse;whiteSpace=wrap;html=1;fillColor=#888888;strokeColor=#888888;" vertex="1" parent="1"><mxGeometry x="580" y="113" width="10" height="10" as="geometry"/></mxCell>
        <mxCell id="n10" value="" style="ellipse;whiteSpace=wrap;html=1;fillColor=#888888;strokeColor=#888888;" vertex="1" parent="1"><mxGeometry x="580" y="133" width="10" height="10" as="geometry"/></mxCell>

        <mxCell id="n11" value="" style="ellipse;whiteSpace=wrap;html=1;fillColor=#c0c0c0;strokeColor=#c0c0c0;" vertex="1" parent="1"><mxGeometry x="620" y="103" width="10" height="10" as="geometry"/></mxCell>
        <mxCell id="n12" value="" style="ellipse;whiteSpace=wrap;html=1;fillColor=#c0c0c0;strokeColor=#c0c0c0;" vertex="1" parent="1"><mxGeometry x="620" y="123" width="10" height="10" as="geometry"/></mxCell>

        <!-- neural lines -->
        <mxCell id="l1" style="endArrow=none;startArrow=none;strokeColor=#666666;strokeWidth=1.5;" edge="1" parent="1" source="n1" target="n4"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="l2" style="endArrow=none;startArrow=none;strokeColor=#666666;strokeWidth=1.5;" edge="1" parent="1" source="n1" target="n5"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="l3" style="endArrow=none;startArrow=none;strokeColor=#666666;strokeWidth=1.5;" edge="1" parent="1" source="n2" target="n5"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="l4" style="endArrow=none;startArrow=none;strokeColor=#666666;strokeWidth=1.5;" edge="1" parent="1" source="n2" target="n6"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="l5" style="endArrow=none;startArrow=none;strokeColor=#666666;strokeWidth=1.5;" edge="1" parent="1" source="n3" target="n6"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="l6" style="endArrow=none;startArrow=none;strokeColor=#666666;strokeWidth=1.5;" edge="1" parent="1" source="n3" target="n7"><mxGeometry relative="1" as="geometry"/></mxCell>

        <mxCell id="l7" style="endArrow=none;startArrow=none;strokeColor=#777777;strokeWidth=1.5;" edge="1" parent="1" source="n4" target="n8"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="l8" style="endArrow=none;startArrow=none;strokeColor=#777777;strokeWidth=1.5;" edge="1" parent="1" source="n5" target="n8"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="l9" style="endArrow=none;startArrow=none;strokeColor=#777777;strokeWidth=1.5;" edge="1" parent="1" source="n5" target="n9"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="l10" style="endArrow=none;startArrow=none;strokeColor=#777777;strokeWidth=1.5;" edge="1" parent="1" source="n6" target="n9"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="l11" style="endArrow=none;startArrow=none;strokeColor=#777777;strokeWidth=1.5;" edge="1" parent="1" source="n6" target="n10"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="l12" style="endArrow=none;startArrow=none;strokeColor=#777777;strokeWidth=1.5;" edge="1" parent="1" source="n7" target="n10"><mxGeometry relative="1" as="geometry"/></mxCell>

        <mxCell id="l13" style="endArrow=none;startArrow=none;strokeColor=#999999;strokeWidth=1.5;" edge="1" parent="1" source="n8" target="n11"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="l14" style="endArrow=none;startArrow=none;strokeColor=#999999;strokeWidth=1.5;" edge="1" parent="1" source="n9" target="n11"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="l15" style="endArrow=none;startArrow=none;strokeColor=#999999;strokeWidth=1.5;" edge="1" parent="1" source="n9" target="n12"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="l16" style="endArrow=none;startArrow=none;strokeColor=#999999;strokeWidth=1.5;" edge="1" parent="1" source="n10" target="n12"><mxGeometry relative="1" as="geometry"/></mxCell>

        <mxCell id="dqn" value="• Deep Q-Network (DQN)" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f2d16b;strokeColor=#d5b14a;fontSize=13;fontStyle=1;align=left;spacingLeft=8;" vertex="1" parent="1">
          <mxGeometry x="448" y="150" width="190" height="18" as="geometry"/>
        </mxCell>

        <mxCell id="actor" value="• Actor-Critic Model" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f2d16b;strokeColor=#d5b14a;fontSize=13;fontStyle=1;align=left;spacingLeft=8;" vertex="1" parent="1">
          <mxGeometry x="448" y="172" width="190" height="18" as="geometry"/>
        </mxCell>

        <!-- Threat classification -->
        <mxCell id="threat" value="Threat Classification" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f2f2f2;strokeColor=#9e9e9e;strokeWidth=2;fontSize=16;fontStyle=1;align=center;verticalAlign=top;spacingTop=10;" vertex="1" parent="1">
          <mxGeometry x="690" y="72" width="150" height="106" as="geometry"/>
        </mxCell>

        <mxCell id="attack" value="Attack" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#1f5aa6;strokeColor=#1f5aa6;fontColor=#ffffff;fontSize=15;fontStyle=1;" vertex="1" parent="1">
          <mxGeometry x="715" y="103" width="100" height="28" as="geometry"/>
        </mxCell>

        <mxCell id="normal" value="Normal" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#2c6cc4;strokeColor=#2c6cc4;fontColor=#ffffff;fontSize=15;fontStyle=1;" vertex="1" parent="1">
          <mxGeometry x="715" y="140" width="100" height="28" as="geometry"/>
        </mxCell>

        <!-- Response actions -->
        <mxCell id="response" value="Response Actions" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f2f2f2;strokeColor=#9e9e9e;strokeWidth=2;fontSize=16;fontStyle=1;align=center;verticalAlign=top;spacingTop=10;" vertex="1" parent="1">
          <mxGeometry x="855" y="72" width="150" height="106" as="geometry"/>
        </mxCell>

        <mxCell id="alert" value="Alert" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f7941d;strokeColor=#f7941d;fontColor=#ffffff;fontSize=15;fontStyle=1;" vertex="1" parent="1">
          <mxGeometry x="880" y="103" width="100" height="28" as="geometry"/>
        </mxCell>

        <mxCell id="block" value="Block" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f7941d;strokeColor=#f7941d;fontColor=#ffffff;fontSize=15;fontStyle=1;" vertex="1" parent="1">
          <mxGeometry x="880" y="140" width="100" height="28" as="geometry"/>
        </mxCell>

        <!-- Bottom label -->
        <mxCell id="bottombar" value="Deep Reinforcement Learning-Based Intrusion Detection System Architecture" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#1f5aa6;strokeColor=#1f5aa6;fontColor=#ffffff;fontSize=15;fontStyle=1;" vertex="1" parent="1">
          <mxGeometry x="150" y="220" width="660" height="24" as="geometry"/>
        </mxCell>

        <!-- Main arrows -->
        <mxCell id="e1" style="endArrow=block;html=1;rounded=0;strokeColor=#3f6fb5;strokeWidth=3;" edge="1" parent="1" source="device1" target="prep"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="e2" style="endArrow=block;html=1;rounded=0;strokeColor=#3f6fb5;strokeWidth=3;" edge="1" parent="1" source="prep" target="featurebox"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="e3" style="endArrow=block;html=1;rounded=0;strokeColor=#3f6fb5;strokeWidth=4;" edge="1" parent="1" source="featurebox" target="drl"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="e4" style="endArrow=block;html=1;rounded=0;strokeColor=#f7941d;strokeWidth=4;" edge="1" parent="1" source="drl" target="threat"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="e5" style="endArrow=block;html=1;rounded=0;strokeColor=#f7941d;strokeWidth=4;" edge="1" parent="1" source="threat" target="response"><mxGeometry relative="1" as="geometry"/></mxCell>

        <!-- Feedback loop -->
        <mxCell id="reward" value="Reward Signals" style="text;html=1;strokeColor=none;fillColor=none;fontSize=14;fontStyle=1;rotation=-8;" vertex="1" parent="1">
          <mxGeometry x="765" y="168" width="120" height="24" as="geometry"/>
        </mxCell>

        <mxCell id="feedback1" style="endArrow=none;html=1;rounded=1;arcSize=25;strokeColor=#f7941d;strokeWidth=4;" edge="1" parent="1" source="response" target="threat">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="938" y="205"/>
              <mxPoint x="865" y="208"/>
              <mxPoint x="820" y="190"/>
            </Array>
          </mxGeometry>
        </mxCell>

        <mxCell id="feedback2" style="endArrow=block;html=1;rounded=1;arcSize=25;strokeColor=#3f6fb5;strokeWidth=2;" edge="1" parent="1" source="response" target="prep">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="930" y="240"/>
              <mxPoint x="930" y="250"/>
              <mxPoint x="200" y="250"/>
              <mxPoint x="200" y="185"/>
            </Array>
          </mxGeometry>
        </mxCell>

      </root>
    </mxGraphModel>
  </diagram>
</mxfile>