<mxfile host="app.diagrams.net" modified="2026-04-25T12:00:00.000Z" agent="ChatGPT" version="24.7.17">
  <diagram id="marl-coordination" name="Page-1">
    <mxGraphModel dx="1400" dy="900" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1200" pageHeight="700" math="0" shadow="0">
      <root>
        <mxCell id="0"/>
        <mxCell id="1" parent="0"/>

        <!-- Top agents -->
        <mxCell id="ta1" value="Agent 1" style="ellipse;whiteSpace=wrap;html=1;fillColor=#f3f6fb;strokeColor=#9aa6b2;strokeWidth=2;fontSize=16;" vertex="1" parent="1">
          <mxGeometry x="20" y="20" width="180" height="55" as="geometry"/>
        </mxCell>
        <mxCell id="ta2" value="Agent 2" style="ellipse;whiteSpace=wrap;html=1;fillColor=#f3f6fb;strokeColor=#9aa6b2;strokeWidth=2;fontSize=16;" vertex="1" parent="1">
          <mxGeometry x="260" y="20" width="180" height="55" as="geometry"/>
        </mxCell>
        <mxCell id="ta3" value="Agent 3" style="ellipse;whiteSpace=wrap;html=1;fillColor=#f3f6fb;strokeColor=#9aa6b2;strokeWidth=2;fontSize=16;" vertex="1" parent="1">
          <mxGeometry x="500" y="20" width="180" height="55" as="geometry"/>
        </mxCell>
        <mxCell id="ta4" value="Agent 4" style="ellipse;whiteSpace=wrap;html=1;fillColor=#f3f6fb;strokeColor=#9aa6b2;strokeWidth=2;fontSize=16;" vertex="1" parent="1">
          <mxGeometry x="740" y="20" width="180" height="55" as="geometry"/>
        </mxCell>

        <!-- Dashed separator line -->
        <mxCell id="sep" value="" style="shape=line;strokeColor=#c7c7c7;strokeWidth=2;dashed=1;dashPattern=8 8;" vertex="1" parent="1">
          <mxGeometry x="10" y="110" width="980" height="1" as="geometry"/>
        </mxCell>

        <!-- Observation labels -->
        <mxCell id="obs1" value="Observation" style="text;html=1;strokeColor=none;fillColor=none;fontSize=15;" vertex="1" parent="1">
          <mxGeometry x="40" y="130" width="120" height="30" as="geometry"/>
        </mxCell>
        <mxCell id="obs2" value="Observation" style="text;html=1;strokeColor=none;fillColor=none;fontSize=15;" vertex="1" parent="1">
          <mxGeometry x="280" y="130" width="120" height="30" as="geometry"/>
        </mxCell>
        <mxCell id="obs3" value="Observation" style="text;html=1;strokeColor=none;fillColor=none;fontSize=15;" vertex="1" parent="1">
          <mxGeometry x="520" y="130" width="120" height="30" as="geometry"/>
        </mxCell>
        <mxCell id="obs4" value="Observation" style="text;html=1;strokeColor=none;fillColor=none;fontSize=15;" vertex="1" parent="1">
          <mxGeometry x="760" y="130" width="120" height="30" as="geometry"/>
        </mxCell>

        <!-- Middle agents -->
        <mxCell id="ma1" value="Agent 1" style="ellipse;whiteSpace=wrap;html=1;fillColor=#356ac3;strokeColor=#356ac3;fontColor=#ffffff;strokeWidth=2;fontSize=16;" vertex="1" parent="1">
          <mxGeometry x="40" y="220" width="140" height="60" as="geometry"/>
        </mxCell>
        <mxCell id="ma2" value="Agent 2" style="ellipse;whiteSpace=wrap;html=1;fillColor=#356ac3;strokeColor=#356ac3;fontColor=#ffffff;strokeWidth=2;fontSize=16;" vertex="1" parent="1">
          <mxGeometry x="280" y="220" width="140" height="60" as="geometry"/>
        </mxCell>
        <mxCell id="ma3" value="Agent 3" style="ellipse;whiteSpace=wrap;html=1;fillColor=#356ac3;strokeColor=#356ac3;fontColor=#ffffff;strokeWidth=2;fontSize=16;" vertex="1" parent="1">
          <mxGeometry x="520" y="220" width="140" height="60" as="geometry"/>
        </mxCell>
        <mxCell id="ma4" value="Agent 4" style="ellipse;whiteSpace=wrap;html=1;fillColor=#356ac3;strokeColor=#356ac3;fontColor=#ffffff;strokeWidth=2;fontSize=16;" vertex="1" parent="1">
          <mxGeometry x="760" y="220" width="140" height="60" as="geometry"/>
        </mxCell>

        <!-- Communication label -->
        <mxCell id="comm" value="Communication &amp; Coordination" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e8e8ee;strokeColor=none;fontSize=15;fontStyle=1;" vertex="1" parent="1">
          <mxGeometry x="300" y="185" width="340" height="35" as="geometry"/>
        </mxCell>

        <!-- Central training -->
        <mxCell id="central" value="Central Training or Coordination" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#2f66bd;strokeColor=#2f66bd;fontColor=#ffffff;strokeWidth=2;fontSize=18;fontStyle=1;" vertex="1" parent="1">
          <mxGeometry x="240" y="420" width="460" height="55" as="geometry"/>
        </mxCell>

        <!-- Bottom boxes -->
        <mxCell id="reward" value="Reward Signals" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#eef4fb;strokeColor=#9aa6b2;strokeWidth=2;fontSize=16;fontColor=#2f66bd;fontStyle=1;" vertex="1" parent="1">
          <mxGeometry x="20" y="520" width="240" height="70" as="geometry"/>
        </mxCell>

        <mxCell id="shared" value="Shared Policy Update" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f7d2a7;strokeColor=#d9a46b;strokeWidth=2;fontSize=16;fontColor=#7a4a0d;fontStyle=1;" vertex="1" parent="1">
          <mxGeometry x="720" y="520" width="250" height="70" as="geometry"/>
        </mxCell>

        <!-- Action labels -->
        <mxCell id="act1" value="Action" style="text;html=1;strokeColor=none;fillColor=none;fontSize=15;" vertex="1" parent="1">
          <mxGeometry x="70" y="330" width="80" height="30" as="geometry"/>
        </mxCell>
        <mxCell id="act2" value="Action" style="text;html=1;strokeColor=none;fillColor=none;fontSize=15;" vertex="1" parent="1">
          <mxGeometry x="310" y="330" width="80" height="30" as="geometry"/>
        </mxCell>
        <mxCell id="act3" value="Action" style="text;html=1;strokeColor=none;fillColor=none;fontSize=15;" vertex="1" parent="1">
          <mxGeometry x="550" y="330" width="80" height="30" as="geometry"/>
        </mxCell>
        <mxCell id="act4" value="Action" style="text;html=1;strokeColor=none;fillColor=none;fontSize=15;" vertex="1" parent="1">
          <mxGeometry x="790" y="330" width="80" height="30" as="geometry"/>
        </mxCell>

        <!-- Observation arrows up -->
        <mxCell id="e1" style="endArrow=block;html=1;strokeColor=#7f7f7f;strokeWidth=2;dashed=1;dashPattern=6 6;" edge="1" parent="1" source="ma1" target="ta1"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="e2" style="endArrow=block;html=1;strokeColor=#7f7f7f;strokeWidth=2;dashed=1;dashPattern=6 6;" edge="1" parent="1" source="ma2" target="ta2"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="e3" style="endArrow=block;html=1;strokeColor=#7f7f7f;strokeWidth=2;dashed=1;dashPattern=6 6;" edge="1" parent="1" source="ma3" target="ta3"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="e4" style="endArrow=block;html=1;strokeColor=#7f7f7f;strokeWidth=2;dashed=1;dashPattern=6 6;" edge="1" parent="1" source="ma4" target="ta4"><mxGeometry relative="1" as="geometry"/></mxCell>

        <!-- Horizontal dashed coordination arrows -->
        <mxCell id="e5" style="startArrow=block;endArrow=block;html=1;strokeColor=#7f7f7f;strokeWidth=2;dashed=1;dashPattern=6 6;" edge="1" parent="1" source="ma1" target="ma2"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="e6" style="startArrow=block;endArrow=block;html=1;strokeColor=#7f7f7f;strokeWidth=2;dashed=1;dashPattern=6 6;" edge="1" parent="1" source="ma2" target="ma3"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="e7" style="startArrow=block;endArrow=block;html=1;strokeColor=#7f7f7f;strokeWidth=2;dashed=1;dashPattern=6 6;" edge="1" parent="1" source="ma3" target="ma4"><mxGeometry relative="1" as="geometry"/></mxCell>

        <!-- Dashed line behind communication label -->
        <mxCell id="e8" style="startArrow=none;endArrow=none;html=1;strokeColor=#7f7f7f;strokeWidth=2;dashed=1;dashPattern=6 6;" edge="1" parent="1">
          <mxGeometry relative="1" as="geometry">
            <mxPoint x="110" y="202" as="sourcePoint"/>
            <mxPoint x="830" y="202" as="targetPoint"/>
          </mxGeometry>
        </mxCell>

        <!-- Action arrows to agents -->
        <mxCell id="e9" style="endArrow=block;html=1;strokeColor=#2f4f7f;strokeWidth=4;" edge="1" parent="1" source="central" target="ma1">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="100" y="448"/>
              <mxPoint x="100" y="380"/>
            </Array>
          </mxGeometry>
        </mxCell>

        <mxCell id="e10" style="startArrow=block;endArrow=block;html=1;strokeColor=#2f4f7f;strokeWidth=4;" edge="1" parent="1" source="central" target="ma2"><mxGeometry relative="1" as="geometry"/></mxCell>
        <mxCell id="e11" style="startArrow=block;endArrow=block;html=1;strokeColor=#2f4f7f;strokeWidth=4;" edge="1" parent="1" source="central" target="ma3"><mxGeometry relative="1" as="geometry"/></mxCell>

        <mxCell id="e12" style="endArrow=block;html=1;strokeColor=#2f4f7f;strokeWidth=4;" edge="1" parent="1" source="central" target="ma4">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="860" y="448"/>
              <mxPoint x="860" y="380"/>
            </Array>
          </mxGeometry>
        </mxCell>

        <!-- Reward signals arrows -->
        <mxCell id="e13" style="endArrow=block;html=1;strokeColor=#356ac3;strokeWidth=4;" edge="1" parent="1">
          <mxGeometry relative="1" as="geometry">
            <mxPoint x="110" y="520" as="sourcePoint"/>
            <mxPoint x="110" y="475" as="targetPoint"/>
          </mxGeometry>
        </mxCell>
        <mxCell id="e14" style="endArrow=block;html=1;strokeColor=#356ac3;strokeWidth=4;" edge="1" parent="1">
          <mxGeometry relative="1" as="geometry">
            <mxPoint x="170" y="520" as="sourcePoint"/>
            <mxPoint x="170" y="475" as="targetPoint"/>
          </mxGeometry>
        </mxCell>

        <!-- Shared policy arrows -->
        <mxCell id="e15" style="endArrow=block;html=1;strokeColor=#356ac3;strokeWidth=4;" edge="1" parent="1">
          <mxGeometry relative="1" as="geometry">
            <mxPoint x="830" y="520" as="sourcePoint"/>
            <mxPoint x="830" y="475" as="targetPoint"/>
          </mxGeometry>
        </mxCell>
        <mxCell id="e16" style="endArrow=block;html=1;strokeColor=#356ac3;strokeWidth=4;" edge="1" parent="1">
          <mxGeometry relative="1" as="geometry">
            <mxPoint x="890" y="520" as="sourcePoint"/>
            <mxPoint x="890" y="475" as="targetPoint"/>
          </mxGeometry>
        </mxCell>

      </root>
    </mxGraphModel>
  </diagram>
</mxfile>