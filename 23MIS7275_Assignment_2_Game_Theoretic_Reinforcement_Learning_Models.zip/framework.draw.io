<mxfile host="app.diagrams.net" modified="2026-04-25T12:00:00.000Z" agent="ChatGPT" version="24.7.17">
  <diagram id="framework-iot-cyber" name="Page-1">
    <mxGraphModel dx="1600" dy="900" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1600" pageHeight="1000" math="0" shadow="0">
      <root>
        <mxCell id="0"/>
        <mxCell id="1" parent="0"/>

        <!-- Title -->
        <mxCell id="title" value="Framework of Game-Theoretic Reinforcement Learning for IoT Cybersecurity" style="text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;fontSize=26;fontStyle=1;" vertex="1" parent="1">
          <mxGeometry x="170" y="20" width="1260" height="40" as="geometry"/>
        </mxCell>

        <!-- Top callout boxes -->
        <mxCell id="adaptive" value="Adaptive Intrusion&#xa;Detection" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="60" y="110" width="220" height="90" as="geometry"/>
        </mxCell>

        <mxCell id="strategic" value="Strategic Attack-Defense&#xa;Modeling" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="1260" y="120" width="270" height="90" as="geometry"/>
        </mxCell>

        <!-- Bottom callout boxes -->
        <mxCell id="multiagent" value="Multi-Agent&#xa;Coordination" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="60" y="760" width="260" height="95" as="geometry"/>
        </mxCell>

        <mxCell id="realtime" value="Real-Time&#xa;Cyber Defense" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="1270" y="760" width="250" height="95" as="geometry"/>
        </mxCell>

        <!-- Main pipeline -->
        <mxCell id="iot" value="IoT Devices /&#xa;Network Traffic" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="10" y="420" width="170" height="110" as="geometry"/>
        </mxCell>

        <mxCell id="monitor" value="Monitoring &amp;&#xa;Feature&#xa;Extraction" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="220" y="410" width="180" height="130" as="geometry"/>
        </mxCell>

        <mxCell id="state" value="State&#xa;Representation" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="450" y="415" width="140" height="120" as="geometry"/>
        </mxCell>

        <mxCell id="attacker" value="Attacker Agent" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="650" y="300" width="170" height="110" as="geometry"/>
        </mxCell>

        <mxCell id="defender" value="Defender Agent" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="650" y="560" width="170" height="110" as="geometry"/>
        </mxCell>

        <mxCell id="game" value="Game-Theoretic&#xa;Interaction&#xa;Module" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="870" y="380" width="170" height="150" as="geometry"/>
        </mxCell>

        <mxCell id="rldrl" value="RL / DRL&#xa;Learning Engine" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="1090" y="400" width="150" height="110" as="geometry"/>
        </mxCell>

        <mxCell id="optimal" value="Optimal Action&#xa;Selection" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=middle;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="1280" y="405" width="140" height="100" as="geometry"/>
        </mxCell>

        <!-- Security response outer box -->
        <mxCell id="security" value="Security Response" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=16;align=center;verticalAlign=top;spacingTop=16;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="1450" y="390" width="170" height="300" as="geometry"/>
        </mxCell>

        <!-- Security response inner boxes -->
        <mxCell id="alert" value="Alert Generation" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=14;align=center;verticalAlign=middle;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="1470" y="450" width="130" height="45" as="geometry"/>
        </mxCell>

        <mxCell id="block" value="Block Malicious Node" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=14;align=center;verticalAlign=middle;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="1462" y="515" width="146" height="45" as="geometry"/>
        </mxCell>

        <mxCell id="isolate" value="Isolate Device" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=14;align=center;verticalAlign=middle;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="1470" y="580" width="130" height="45" as="geometry"/>
        </mxCell>

        <mxCell id="policy" value="Policy Update" style="rounded=1;whiteSpace=wrap;html=1;strokeColor=#1a5fb4;fillColor=#ffffff;fontSize=14;align=center;verticalAlign=middle;strokeWidth=2;" vertex="1" parent="1">
          <mxGeometry x="1470" y="645" width="130" height="45" as="geometry"/>
        </mxCell>

        <!-- Feedback label -->
        <mxCell id="feedbackLabel" value="Reward / Penalty Feedback" style="text;html=1;strokeColor=none;fillColor=none;fontSize=14;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="780" y="725" width="350" height="30" as="geometry"/>
        </mxCell>

        <!-- Caption -->
        <mxCell id="caption" value="Figure: Conceptual framework showing attacker-defender interaction, adaptive learning, and response generation in IoT cybersecurity." style="text;html=1;strokeColor=none;fillColor=none;fontSize=15;align=center;verticalAlign=middle;" vertex="1" parent="1">
          <mxGeometry x="120" y="930" width="1360" height="30" as="geometry"/>
        </mxCell>

        <!-- Main arrows -->
        <mxCell id="e1" style="endArrow=block;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="iot" target="monitor">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <mxCell id="e2" style="endArrow=block;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="monitor" target="state">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <mxCell id="e3" style="endArrow=block;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="state" target="attacker">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="590" y="360"/>
            </Array>
          </mxGeometry>
        </mxCell>

        <mxCell id="e4" style="endArrow=block;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="state" target="defender">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="590" y="610"/>
            </Array>
          </mxGeometry>
        </mxCell>

        <mxCell id="e5" style="endArrow=block;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="attacker" target="game">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <mxCell id="e6" style="endArrow=block;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="defender" target="game">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <mxCell id="e7" style="endArrow=block;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="game" target="rldrl">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <mxCell id="e8" style="endArrow=block;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="rldrl" target="optimal">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <mxCell id="e9" style="endArrow=block;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="optimal" target="security">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>

        <!-- Feedback loop -->
        <mxCell id="e10" style="endArrow=block;html=1;rounded=0;strokeColor=#000000;strokeWidth=2;" edge="1" parent="1" source="security" target="rldrl">
          <mxGeometry relative="1" as="geometry">
            <Array as="points">
              <mxPoint x="1540" y="760"/>
              <mxPoint x="1165" y="760"/>
              <mxPoint x="1165" y="560"/>
            </Array>
          </mxGeometry>
        </mxCell>

      </root>
    </mxGraphModel>
  </diagram>
</mxfile>